<div class="menu">
    <a href="index.php">Home</a>
    <a href="index.php?page=profil">Profil</a>
    <a href="index.php?page=kontak">Kontak</a>
    <a href="index.php?page=galeri">Galeri</a>
</div>