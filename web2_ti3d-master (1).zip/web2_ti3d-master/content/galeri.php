<div class="card">
    <h2>Galeri</h2>
    <form action="index.php?page=galeri_upload" method="POST" enctype="multipart/form-data">
        <input type="file" name="gambar">
        <button type="submit">Upload</button>
    </form>
</div>