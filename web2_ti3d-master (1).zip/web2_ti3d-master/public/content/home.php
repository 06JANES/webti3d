<div class="row">
    <div class="col-12">
        <h1>Home</h1>
        <p>Selamat Datang <?= $user; ?>, anda login menggunakan level <?= $level ?></p>
    </div>
</div>